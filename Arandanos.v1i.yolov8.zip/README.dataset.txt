# Arandanos > 2023-11-23 11:40am
https://universe.roboflow.com/uc-lb0wd/arandanos-hz94p

Provided by a Roboflow user
License: CC BY 4.0

